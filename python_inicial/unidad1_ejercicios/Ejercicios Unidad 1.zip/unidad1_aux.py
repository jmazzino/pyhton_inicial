# Esto es un comentario
"""
Hola curso,
Esto también es un comentario pero multilínea.
"""
"""from tkinter import *
Label(text='Hola').pack()
mainloop()"""

a = 3  # Es un entero
a = "Manzana"  # Ahora es un string
a = 1.23  # Ahora es un número flotante
"""
from tkinter import *

root = Tk()
e = Entry(root)
e.pack()
e.focus_set()
a = 5
b = 2
c = a * b
var = IntVar()
e.config(textvariable=var)
var.set(c)
mainloop()
"""
