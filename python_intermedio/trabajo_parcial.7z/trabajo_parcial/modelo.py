from tkinter import *
from sqlite3 import Error
import sqlite3


class Abmc:
    def conectar(self):
        try:
            con = sqlite3.connect("agenda.db")
            return con
        except Error:
            print(Error)

    def alta(self, nombre, apellido, interno, email):
        # def insertarregistro(con, nombre, apellido, interno, email):
        params = (nombre, apellido, interno, email)
        con = self.conectar()
        cursorObj = con.cursor()
        cursorObj.execute("INSERT INTO personas VALUES( NULL,?, ?, ?, ?)", params)
        con.commit()

        # insertarregistro(con, nombre, apellido, interno, email)
